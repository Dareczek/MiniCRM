delete dbo.ClientOrder;
delete dbo.Orderik;
delete dbo.Product;
delete dbo.Client;