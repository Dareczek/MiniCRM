drop table dbo.ClientOrder;
drop table dbo.Orderik;
drop table dbo.Product;
drop table dbo.Client;